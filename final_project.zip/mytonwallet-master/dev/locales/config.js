const i18nDir = './src/i18n';

module.exports = { i18nDir };
