package org.mytonwallet.plugins.nativebottomsheet;

import android.util.Log;

public class BottomSheet {

    public String echo(String value) {
        Log.i("Echo", value);
        return value;
    }
}
