import UIKit

UIApplicationMain(
    CommandLine.argc,
    CommandLine.unsafeArgv,
    NSStringFromClass(MyTonWalletApp.self),
    NSStringFromClass(AppDelegate.self)
)
