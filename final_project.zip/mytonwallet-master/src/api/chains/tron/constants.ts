export const TRON_GAS = {
  transferTrc20Estimated: 28_214_970n,
};
