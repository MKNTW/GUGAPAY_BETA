export const SEC = 1000;
export const MINUTE = 60 * SEC;
export const DAYS_IN_YEAR = 365;
export const FIRST_TRANSACTIONS_LIMIT = 50;
